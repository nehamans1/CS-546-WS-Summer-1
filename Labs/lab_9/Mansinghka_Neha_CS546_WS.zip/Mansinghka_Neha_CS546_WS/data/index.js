//exports.users = require('./users');
const usersData = require("./users");
//const commentsData = require("./comments");

module.exports = {
    //comments: commentsData,
    users: usersData
};